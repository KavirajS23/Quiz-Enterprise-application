-- MySQL dump 10.13  Distrib 5.5.52, for Win64 (x86)
--
-- Host: localhost    Database: signupdb
-- ------------------------------------------------------
-- Server version	5.5.52

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `ans`
--

DROP TABLE IF EXISTS `ans`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ans` (
  `sno` varchar(20) DEFAULT NULL,
  `answer` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ans`
--

LOCK TABLES `ans` WRITE;
/*!40000 ALTER TABLE `ans` DISABLE KEYS */;
INSERT INTO `ans` VALUES ('1','James Gosling'),('2','Timbernesley'),('3','img'),('4','1997'),('5','Lion');
/*!40000 ALTER TABLE `ans` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qa`
--

DROP TABLE IF EXISTS `qa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qa` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(500) DEFAULT NULL,
  `option1` varchar(30) DEFAULT NULL,
  `option2` varchar(30) DEFAULT NULL,
  `option3` varchar(30) DEFAULT NULL,
  `option4` varchar(30) DEFAULT NULL,
  `c_ans` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qa`
--

LOCK TABLES `qa` WRITE;
/*!40000 ALTER TABLE `qa` DISABLE KEYS */;
INSERT INTO `qa` VALUES (1,' Which of these packages contain all the collection classes?','java.lang','java.util','java.net','java.awt','java.util'),(2,'Which of these classes is not part of Java\'s collection framework?','Maps','Array','Stack','Queue','Queue'),(3,'Which of these interface is not a part of Java\'s collection framework?','List','Set','SortedMap','SortedList','SortedList'),(4,'Which of these methods deletes all the elements from invoking collection?','clear()','reset()','delete()','refresh()','clear()'),(5,'Which is Collection in java?','A group of objects','A group of classes','A group interfaces','None of the mentioned','A group of objects'),(6,'Which of these interface declares core method that all collections will have?','Set','EventListner','Comparator','Collection','Collection'),(7,' Which of these interface handle sequences?','Set','List','Comparator','Collection','List'),(8,'Which of these interface must contain a unique element?','Set','List','Array','Collection','Set'),(9,'Which of these is Basic interface that all other interface inherits?','Set','Array','List','Collection','Collection'),(10,'Which of these functions is called to display the output of an applet?','display()','print()','displayApplet()','PrintApplet()','print()'),(11,'Which of these methods can be used to output a string in an applet?','display()','print()','drawstring()','transient()','drawString()'),(12,'What does AWT stands for?','All Window Tools','All Writing Tools','Abstract Window Toolkit','Abstract Writing Toolkit','Abstract window Toolkit'),(13,'Which of these methods is a part of Abstract Window Toolkit(AWT)?','display()','print()','drawString()','transient()','print()'),(14,'Which of the modifier can be used for a variable so that it can be accesed from any thread or parts of a program?','transient','volatile','global','No modifier is needed','volatile'),(15,'Which of these operators can be used to get run time information about an object?','getInfo','Info','instanceOf','getinfoof','instanceOf'),(16,'Which of these is a process of writing the state of an object to a byte stream? ','Serialization','Externilization','File Filtering','All Of Mentioned','Serialization'),(17,'Which of these process occur automatically by java run time system?','Serialization','Garbage Collection','File Filtering','All Of Mentioned','Serialization'),(18,'Which of these is an interface for control over serialization and deserialization?','Serialization','Externalization','File Filter','Object Input','Extenilisation'),(19,'Which of these is a method of ObjectOutput interface used to finalize the output state so that any buffers are cleared?','clear()','flush()','fflush()','close()','flush()'),(20,'Which of these is method of ObjectOutput interface used to write the object to input or output stream as required?','Write()','write()','SytreamWrite()','writeObject()','writeObject()'),(21,'Which of these is a process of extracting/removing the state of an object from a stream?','Serialization','Externalization','File Filtering','Deserialization','Deserialization'),(22,'Which of these process occur automatically by java run time system?','Serialization','Memory allocation','Deserialization','All Of mentioned','All Of memtioned'),(23,'Which of these is an interface for control over serialization and deserialization?','Serializable','Externalization','FileFilter','ObjectInput','Externalization'),(24,'Which of these interface extends DataInput interface?','Serializable','Externalization','ObjectOutput','ObjectInput','ObjectInput'),(25,' Which of these is a method of ObjectInput interface used to deserialize an object from a stream?','int read()','void close()','Object readObject','Object WriteObject','Object redObject()'),(26,'Preprocessor feature that supply line numbers and file names to compiler is called?','Selective inclusion','macro substitution','Concatenation','Line control','Line control'),(27,'.If there is any error while opening a file, fopen will return?','Nothing','EOF','NULL','Depends on compiler','NULL'),(28,'The keyword `break\' cannot be simply used within:','do-while','if-else','for','while','if-else'),(29,'.Which keyword can be used for coming out of recursion?','break','return','exit','Both (a) and (b)','return'),(30,'How many types of inheritance are there in c++?','2','3','4','5','5');
/*!40000 ALTER TABLE `qa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result` (
  `name` varchar(100) DEFAULT NULL,
  `total` varchar(100) DEFAULT NULL,
  `mailid` varchar(100) DEFAULT NULL,
  `pno` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES ('raj','0',NULL,NULL),('sri','4','srikhanth@gmail.com',NULL),('sharmi','5','srikhanth@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),('suriya','0','suriyadgp@gmail.com',NULL),(NULL,'0',NULL,NULL),('sabi','7','sabina@gmail.com',NULL),('Sreekee','15','jsrikanthit2386@gmail.com',NULL),('ad','1','dsi',NULL),('suriya','0','suriyadgp@gmail.com','9698375963'),('w','1','sad','w'),('w','1','sad','w'),('ad','0','a',NULL),('ad','0','a',NULL),('sharmi','0',NULL,NULL),('sharmi','0',NULL,NULL),('sharmi','0',NULL,NULL),('tt','0','t',NULL);
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `fname` varchar(100) DEFAULT NULL,
  `lname` varchar(100) DEFAULT NULL,
  `mail` varchar(100) DEFAULT NULL,
  `pno` varchar(100) DEFAULT NULL,
  `uname` varchar(100) DEFAULT NULL,
  `pwrd` varchar(100) DEFAULT NULL,
  `rpwrd` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('sharmila','m','sharmimubarak','90000000776','sharmi','123',NULL),('sharmila','m','sharmimubarak','23345','suri','234',NULL),('suri','s','sssss','98765','kavi','123',NULL),('s1','a','s','d','remo','sks',NULL),('mangai','m','qwe','685944993','mansi','33',NULL),('rajesh','r','qwerty','9095067768','raj','51',NULL),('indhumathi','m','qqqqqqqqq@gmail.com','456789087','indhu','15',NULL),('m','m','m','m','m','m',NULL),('srikhanth','s','srikhanth@gmail.com','987678866','sri','6369',NULL),('suri','s','suriyadgp@gmail.com','9698375963','suriya','suri',NULL),('Ayisha Sabeena','m','sabina@gmail.com','9543430719','sabi','3',NULL),('A','A','A','A','A','A',NULL),('Srikanth','Janarthanan','jsrikanthit2386@gmail.com','9894257672','Sreekee','admin',NULL),('rew','sdf','dsi','987897','ad','ad',NULL),('suri','suri','suriyadgp@gmail.com','9698375963','suriya','suri',NULL),('q','q','sad','w','w','w',NULL),('q','q','sad','w','w','w',NULL),('q','q','sad','w','w','w',NULL),('a','a','a','a','ad','a',NULL),('a','a','a','a','a','a',NULL),('a','qaa','sdd','ss','c','c',NULL),('t','t','t','t','t','t',NULL),('t','t','t','t','tt','t',NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-02-01 16:22:22
